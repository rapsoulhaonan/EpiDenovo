// renamed
define( "JBrowse/Store/Sequence/StaticChunked", [ 'JBrowse/Store/SeqFeature/SequenceChunks' ], function(s) { return s; } );
